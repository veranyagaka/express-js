const express = require('express')
const app =express()
app.listen(3000)

app.set('view engine','ejs')
//we need routes / is just the current or root path
app.get('/', (req,res)=>{
   // res.sendStatus(500); //you can chain status with other eg res.status(500).send("Hi") 
    //res.json({message: "Warning: ERROR"});
    //res.send("It works!");
    //res.download
    res.render('index', {text: " World!"});
});
//console.log("Hey Vera");

const drugsRouter = require('./routes/drugs');
app.use('/drugs', drugsRouter)