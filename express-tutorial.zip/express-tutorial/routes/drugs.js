const express =require('express');
const router =express.Router();
//static routes
router.get('/list',(req,res)=>{
    res.send("Lists of all the Drugs")
   
})
router.get('/new', (req, res)=>{
    res.send("New Drugs")
})
//to get info from user such as a new dug
router.get('/', (req,res)=>{
    res.send("You")
})
//dynamic routes
//getting individual drugs
   

router
.route('/:id')

.get((req,res)=>{
    console.log(req.drugs)
    let drugId = req.params.id; 
    res.send(`GET Drug with Id ${drugId}`)

})//update
.put((req,res)=>{
    let drugId = req.params.id; 
        res.send(`UPDATE Drug with Id ${drugId}`)

})//delete
.delete((req,res)=>{
    let drugId = req.params.id;
        res.send(`DELETEwith Id ${drugId}`)

})
const drugs =[{name: "Piriton"},{name: "Bascopan"}]
router.param('id',(req,res,next,id)=>{
    console.log(id)
    req.drugs = drugs[id]
    next()
})
module.exports= router