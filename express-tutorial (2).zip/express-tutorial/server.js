
const express = require('express')
const app =express()
app.listen(3000,
    console.log("Server is running on port 3000"))

//database mysql
const mysql = require('mysql')

const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password:'',
    database: 'trial'
})
//create a route

app.get('/vera', (req,res) =>{
    const sql = "SELECT * FROM tests"
    db.query(sql, (err, data)=>{
        if(err){return res.json("ERROR")}
        return res.json(data)
        
    })
})
//implement crud functionalities here


app.use(express.static("public")) //for all the static routes=that dont change
app.set('view engine','ejs')
//we need routes / is just the current or root path
/* app.get('/', (req,res)=>{
   // res.sendStatus(500); //you can chain status with other eg res.status(500).send("Hi") 
    //res.json({message: "Warning: ERROR"});
    //res.send("It works!");
    //res.download
    //res.render('index', {text: " World!"});
}); */
//console.log("Hey Vera");

//for forms for it to access data in the body
app.use(express.urlencoded({extended : true}))
app.use(express.json())


const drugsRouter = require('./routes/drugs');
app.use('/drugs', drugsRouter)

