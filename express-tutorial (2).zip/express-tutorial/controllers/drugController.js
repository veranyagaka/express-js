const express =require("express")
const drugController = express.drugController

const newDrug=




module.exports=drugController